<?php 
Class Database{
 private $connection;

 public function __construct($host){
  $this->connection = new PDO("mysql:host=$host;dbname=TIKKLE", "root", "system");
  $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $this->connection->exec("USE TIKKLE");
 }
  public function insert_user_info($user_id, $user_name,  $inquiry_token, $withdraw_token, $deposit_token){
    $this->connection->exec("INSERT INTO user_info ($user_id, $user_name, $inquiry_token, $withdraw_token, $deposit_token) VALUES(\"$user_id\", \"$user_name\", \"$inquiry_token\", \"$withdraw_token\", \"$deposit_token\")");
  }
  public function insert_user_account($user_number, $account_fin_number, $bank_code, $account_number){
    $this->connection->exec("INSERT INTO insert_user_account VALUES(\"$user_number\", \"$account_fin_number\", \"$bank_code\", \"$account_number\")");
  }
  public function insert_bank_info($bank_code, $bank_name){
  	$this->connection->exec("INSERT INTO insert_bank_info VALUES(\"$bank_code\", \"$bank_name\")");
  }
  public function insert_room_info($roomName, $roomPrice, $roomPeople, $roomType, $roomRatio){
  	$this->connection->exec("INSERT INTO insert_room_info VALUES(\"roomName\", \"roomPrice\", \"$roomPeople\", \"$roomType\", \"$roomRatio\")");
  }
}
 ?>
